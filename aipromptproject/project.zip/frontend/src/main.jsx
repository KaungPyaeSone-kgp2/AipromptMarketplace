import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router";
import App from "./App.jsx";
import { ShopProvider } from "./users/context/ShopContext.jsx";
import { ToastProvider } from "./users/components/Toast.jsx";
import { SocketProvider } from "./users/context/SocketContext.jsx";
import SocketListener from "../../websocket/SocketListener.jsx";
import "./index.css";
import "./App.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <SocketProvider>
        <ToastProvider>
          <ShopProvider>
            <SocketListener />
            <App />
          </ShopProvider>
        </ToastProvider>
      </SocketProvider>
    </BrowserRouter>
  </React.StrictMode>
);
