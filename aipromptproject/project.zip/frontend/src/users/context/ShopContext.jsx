import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  useRef,
} from "react";
import {
  addWishlistPrompt,
  deleteWishlistPrompt,
  fetchWishlist,
} from "../services/wishlistService.js";
import { updatePromptInCache } from "../services/promptService.js";


const ShopContext = createContext(null);


export function ShopProvider({ children }) {
  const [wishlist, setWishlist] = useState([]);
  const [wishlistUnseen, setWishlistUnseen] = useState(0);
  const pendingToggles = useRef(new Set());

  useEffect(() => {
    let cancelled = false;

    async function loadWishlist() {
      try {
        const savedWishlist = await fetchWishlist();
        if (!cancelled) setWishlist(savedWishlist);
      } catch (error) {
        console.error("Failed to load wishlist", error);
      }
    }

    loadWishlist();

    return () => {
      cancelled = true;
    };
  }, []);


  const isInWishlist = useCallback(
    (promptId) => wishlist.some((item) => item.id === String(promptId)),
    [wishlist]
  );


  const toggleWishlist = useCallback(async (prompt) => {
    const id = String(prompt.id);
    if (pendingToggles.current.has(id)) return;
    pendingToggles.current.add(id);

    const exists = wishlist.some((p) => p.id === id);

    setWishlist((prev) =>
      exists ? prev.filter((p) => p.id !== id) : [...prev, prompt]
    );
    if (!exists) {
      setWishlistUnseen((count) => count + 1);
      updatePromptInCache(id, {
        wishlistCount: Math.max(0, (prompt.wishlistCount ?? 0) + 1),
      });
    } else {
      setWishlistUnseen((count) => Math.max(0, count - 1));
      updatePromptInCache(id, {
        wishlistCount: Math.max(0, (prompt.wishlistCount ?? 0) - 1),
      });
    }

    try {
      if (exists) {
        await deleteWishlistPrompt(id);
      } else {
        await addWishlistPrompt(id);
      }
    } catch (error) {
      console.error("Failed to update wishlist", error);
      setWishlist((prev) =>
        exists
          ? prev.some((p) => p.id === id)
            ? prev
            : [...prev, prompt]
          : prev.filter((p) => p.id !== id)
      );
      if (!exists) {
        setWishlistUnseen((count) => Math.max(0, count - 1));
        updatePromptInCache(id, {
          wishlistCount: Math.max(0, (prompt.wishlistCount ?? 0)),
        });
      } else {
        setWishlistUnseen((count) => count + 1);
        updatePromptInCache(id, {
          wishlistCount: Math.max(0, (prompt.wishlistCount ?? 0)),
        });
      }
    } finally {
      pendingToggles.current.delete(id);
    }
  }, [wishlist]);

  const removeFromWishlist = useCallback(async (promptId) => {
    const id = String(promptId);
    const removedPrompt = wishlist.find((p) => p.id === id);

    setWishlist((prev) => prev.filter((p) => p.id !== id));
    setWishlistUnseen((count) => Math.max(0, count - 1));
    
    if (removedPrompt) {
      updatePromptInCache(id, {
        wishlistCount: Math.max(0, (removedPrompt.wishlistCount ?? 0) - 1),
      });
    }

    try {
      await deleteWishlistPrompt(id);
    } catch (error) {
      console.error("Failed to remove wishlist item", error);
      if (removedPrompt) {
        setWishlist((prev) =>
          prev.some((p) => p.id === id) ? prev : [...prev, removedPrompt]
        );
        setWishlistUnseen((count) => count + 1);
        updatePromptInCache(id, {
          wishlistCount: Math.max(0, (removedPrompt.wishlistCount ?? 0)),
        });
      }
    }
  }, [wishlist]);

  const markWishlistSeen = useCallback(() => setWishlistUnseen(0), []);

  const value = useMemo(
    () => ({
      wishlist,
      wishlistCount: wishlist.length,
      wishlistUnseenCount: wishlistUnseen,
      isInWishlist,
      toggleWishlist,
      removeFromWishlist,
      markWishlistSeen,
    }),
    [
      wishlist,
      wishlistUnseen,
      isInWishlist,
      toggleWishlist,
      removeFromWishlist,
      markWishlistSeen,
    ]
  );

  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>;
}

export function useShop() {
  const ctx = useContext(ShopContext);
  if (!ctx) throw new Error("useShop must be used within ShopProvider");
  return ctx;
}
