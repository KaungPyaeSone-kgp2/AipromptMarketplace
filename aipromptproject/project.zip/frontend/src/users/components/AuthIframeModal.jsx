import React, { useEffect } from "react";

export default function AuthIframeModal({ onLoginSuccess }) {
  useEffect(() => {
    const handleMessage = (event) => {
      if (event.data && event.data.type === "LOGIN_SUCCESS") {
        const userId = event.data.userId;
        sessionStorage.setItem("promptai_user_id", userId);
        onLoginSuccess();
      }
    };

    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, [onLoginSuccess]);

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black">
      <div className="w-full h-full bg-[#050505] overflow-hidden relative">
        <iframe
          src="/login_register/Landing/index.php"
          className="w-full h-full border-0"
          title="Login / Register"
        />
      </div>
    </div>
  );
}
