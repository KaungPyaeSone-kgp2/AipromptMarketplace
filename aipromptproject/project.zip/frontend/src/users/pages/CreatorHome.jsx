import React, { useEffect, useState } from "react";
import { Link } from "react-router";
import PromptCard from "../components/PromptCard";
import { fetchCreatorPrompts, fetchDraftPrompts, updatePromptVisibility, PROMPTS_UPDATED_EVENT } from "../services/promptService.js";
import { MagicIcon } from "../components/Icon.jsx";

const getVisibilityLabel = (value) => {
  switch (value) {
    case 'followers_only': return 'Only Followings';
    case 'draft': return 'Draft';
    default: return 'Public';
  }
};

export default function CreatorHome() {
  const [activeTab, setActiveTab] = useState("published"); // "published" | "drafts"
  const [publishedPrompts, setPublishedPrompts] = useState([]);
  const [draftPrompts, setDraftPrompts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openDropdownId, setOpenDropdownId] = useState(null);

  async function loadPrompts(showLoader = true) {
    if (showLoader) setLoading(true);
    try {
      const [published, drafts] = await Promise.all([
        fetchCreatorPrompts(),
        fetchDraftPrompts(),
      ]);
      setPublishedPrompts(published || []);
      setDraftPrompts(drafts || []);
    } catch (error) {
      console.error("Failed to load prompts", error);
    } finally {
      if (showLoader) setLoading(false);
    }
  }

  useEffect(() => {
    loadPrompts();

    const handlePromptsUpdated = () => loadPrompts(false);
    window.addEventListener(PROMPTS_UPDATED_EVENT, handlePromptsUpdated);
    return () => {
      window.removeEventListener(PROMPTS_UPDATED_EVENT, handlePromptsUpdated);
    };
  }, []);

  useEffect(() => {
    const handleClickOutside = () => setOpenDropdownId(null);
    window.addEventListener("click", handleClickOutside);
    return () => window.removeEventListener("click", handleClickOutside);
  }, []);

  const handleVisibilityChange = async (promptId, newVisibility) => {
    try {
      await updatePromptVisibility(promptId, newVisibility);
      // Reload prompts after visibility change to reflect new categories
      await loadPrompts();
    } catch (error) {
      console.error("Failed to update visibility", error);
      alert("Failed to update prompt visibility");
    }
  };

  const displayedPrompts = activeTab === "published" ? publishedPrompts : draftPrompts;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-4xl font-black text-violet-400 tracking-tight">
            Created Prompts
          </h1>
          {/* <p className="mt-2 text-lg text-slate-400 font-medium">Manage your prompts and track their performance.</p> */}
        </div>

        <Link
          to="/createpost"
          className="flex items-center gap-2 rounded-xl bg-violet-600 px-5 py-2.5 text-sm font-bold text-white transition-all duration-200 hover:scale-105 hover:bg-violet-500 hover:shadow-lg hover:shadow-violet-500/25"
        >
          <div className="h-4 w-4">
            <MagicIcon />
          </div>
          Create Prompt
        </Link>
      </div>

      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab("published")}
          className={`rounded-lg px-4 py-2 text-sm font-bold transition-all ${activeTab === "published"
            ? "bg-violet-500/20 text-violet-300"
            : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-300"
            }`}
        >
          Published ({publishedPrompts.length})
        </button>
        <button
          onClick={() => setActiveTab("drafts")}
          className={`rounded-lg px-4 py-2 text-sm font-bold transition-all ${activeTab === "drafts"
            ? "bg-violet-500/20 text-violet-300"
            : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-300"
            }`}
        >
          Drafts ({draftPrompts.length})
        </button>
      </div>

      {loading ? (
        <div className="glass-panel p-10 text-center text-sm text-slate-400">
          Loading your prompts...
        </div>
      ) : displayedPrompts.length > 0 ? (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {displayedPrompts.map((prompt) => (
            <PromptCard
              key={prompt.id}
              prompt={prompt}
              actionLabel="Manage"
              actionTo={`/createpost/${prompt.id}`}
              showVisibilityInfo={true}
            >
              <div className="mt-4 flex items-center justify-between border-t border-slate-700/50 pt-4">
                <span className="text-xs font-bold text-slate-400">Visibility:</span>

                {/* Custom Select Wrapper */}
                <div className="relative">
                  {/* The Trigger Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setOpenDropdownId(openDropdownId === prompt.id ? null : prompt.id);
                    }}
                    className="flex items-center justify-between min-w-[120px] rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-white focus:border-violet-500 focus:outline-none focus:ring-1 focus:ring-violet-500"
                  >
                    {getVisibilityLabel(prompt.visibility || "public")}
                    <svg className="ml-2 h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>

                  {/* The Options Menu */}
                  {openDropdownId === prompt.id && (
                    <div className="absolute right-0 bottom-full mb-1 z-10 w-full min-w-[120px] origin-bottom-right rounded-lg border border-slate-700 bg-slate-800 py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                      <button
                        type="button"
                        onClick={() => {
                          handleVisibilityChange(prompt.id, "public");
                          setOpenDropdownId(null);
                        }}
                        className="block w-full px-3 py-2 text-left text-xs font-medium text-white hover:bg-violet-600 focus:bg-violet-600 focus:outline-none transition-colors rounded-t-lg"
                      >
                        Public
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          handleVisibilityChange(prompt.id, "followers_only");
                          setOpenDropdownId(null);
                        }}
                        className="block w-full px-3 py-2 text-left text-xs font-medium text-white hover:bg-violet-600 focus:bg-violet-600 focus:outline-none transition-colors"
                      >
                        Only Followings
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          handleVisibilityChange(prompt.id, "draft");
                          setOpenDropdownId(null);
                        }}
                        className="block w-full px-3 py-2 text-left text-xs font-medium text-white hover:bg-violet-600 focus:bg-violet-600 focus:outline-none transition-colors rounded-b-lg"
                      >
                        Draft
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </PromptCard>
          ))}
        </div>
      ) : (
        <div className="glass-panel p-10 text-center text-sm text-slate-400">
          {activeTab === "published"
            ? "You have not published any prompts yet."
            : "You have no drafts."}
        </div>
      )}
    </div>
  );
}