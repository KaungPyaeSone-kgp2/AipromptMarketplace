import React, { useEffect, useState } from "react";
import { fetchReports } from "../services/reportService.js";
import { getCurrentUserId } from "../services/currentUser.js";

const ReportCard = ({ report, isReceived }) => {
  const formatTimeAgo = (dateStr) => {
    if (!dateStr) return "";
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now - date;
    const diffMin = Math.floor(diffMs / 60000);
    const diffHr = Math.floor(diffMs / 3600000);
    const diffDay = Math.floor(diffMs / 86400000);

    if (diffMin < 1) return "Just now";
    if (diffMin < 60) return `${diffMin}m ago`;
    if (diffHr < 24) return `${diffHr}h ago`;
    if (diffDay < 7) return `${diffDay}d ago`;
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: date.getFullYear() !== now.getFullYear() ? "numeric" : undefined });
  };

  const getTargetLabel = () => {
    switch (report.target_type) {
      case "prompt": return isReceived ? `Your Prompt: ${report.prompt_title}` : `Prompt: ${report.prompt_title || "Unknown"}`;
      case "user": return isReceived ? "Your Account" : `User: ${report.reported_username || "Unknown"}`;
      case "comment": return isReceived ? "Your Review" : `Review: "${report.review_text?.substring(0, 30)}..."`;
      default: return "Unknown Target";
    }
  };

  return (
    <div className="group relative overflow-hidden rounded-2xl border border-slate-700/60 bg-slate-900/50 p-5 transition-all hover:border-slate-500/60 hover:bg-slate-900/80">
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-black uppercase tracking-wider text-violet-400">
              {report.target_type} Report
            </span>
            <span className={`px-2 py-0.5 rounded-md text-[9px] uppercase tracking-widest font-black ${
              report.status === 'pending' ? 'bg-amber-500/20 text-amber-300' :
              report.status === 'resolved' ? 'bg-emerald-500/20 text-emerald-300' :
              report.status === 'rejected' ? 'bg-rose-500/20 text-rose-300' :
              'bg-blue-500/20 text-blue-300'
            }`}>
              {report.status}
            </span>
          </div>
          <h4 className="text-base font-bold text-white group-hover:text-violet-300 transition-colors">
            {getTargetLabel()}
          </h4>
          <p className="text-sm text-slate-400">
            <span className="font-medium text-slate-300">Reason:</span> {report.reason.replace("_", " ")}
          </p>
        </div>
        <span className="shrink-0 text-[10px] font-medium text-slate-500">{formatTimeAgo(report.created_at)}</span>
      </div>

      {report.report_description && (
        <div className="mt-4 rounded-xl bg-slate-950/50 p-3 text-xs italic text-slate-400 border border-slate-800/50">
          "{report.report_description}"
        </div>
      )}
    </div>
  );
};

export default function CreatorReports() {
  const [reports, setReports] = useState({ submitted: [], received: [] });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("received");

  useEffect(() => {
    const loadData = async () => {
      try {
        const userId = getCurrentUserId();
        if (userId) {
          const data = await fetchReports(userId);
          if (data.success) {
            setReports({
              submitted: data.submitted,
              received: data.received // Creator see all, including prompt reports
            });
          }
        }
      } catch (error) {
        console.error("Failed to fetch reports:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  if (loading) {
    return (
      <div className="-m-6 min-h-[calc(100vh-4rem)] bg-[#100d18] p-10 text-center text-slate-400">
        Loading reports...
      </div>
    );
  }

  const currentList = activeTab === "submitted" ? reports.submitted : reports.received;

  return (
    <div className="fade-in -m-6 min-h-[calc(100vh-4rem)] bg-[#100d18] px-6 py-8 text-slate-100 sm:px-8 lg:px-10">
      <div className="mx-auto max-w-4xl space-y-10">
        <div>
          <h1 className="text-5xl font-black text-white tracking-tight">Creator Reports</h1>
          <p className="mt-4 text-lg text-slate-300">Monitor reports filed against your content and your submissions.</p>
        </div>

        <div className="flex gap-2 p-1 rounded-2xl bg-slate-900/50 border border-slate-700/30 w-fit">
          <button
            onClick={() => setActiveTab("received")}
            className={`px-8 py-2.5 rounded-xl text-sm font-bold transition-all ${
              activeTab === "received" ? "bg-violet-600 text-white shadow-lg shadow-violet-600/20" : "text-slate-400 hover:text-white"
            }`}
          >
            Against Me ({reports.received.length})
          </button>
          <button
            onClick={() => setActiveTab("submitted")}
            className={`px-8 py-2.5 rounded-xl text-sm font-bold transition-all ${
              activeTab === "submitted" ? "bg-violet-600 text-white shadow-lg shadow-violet-600/20" : "text-slate-400 hover:text-white"
            }`}
          >
            Submitted ({reports.submitted.length})
          </button>
        </div>

        <div className="grid gap-5">
          {currentList.length === 0 ? (
            <div className="rounded-3xl border-2 border-dashed border-slate-800 bg-slate-950/20 p-20 text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-900 text-slate-500 mb-6 shadow-xl">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              </div>
              <h3 className="text-xl font-black text-slate-300 mb-2">No Reports Found</h3>
              <p className="text-slate-500 font-medium max-w-sm mx-auto">There are no reports to display in this category at the moment.</p>
            </div>
          ) : (
            currentList.map(report => (
              <ReportCard key={`${report.target_type}-${report.id}`} report={report} isReceived={activeTab === 'received'} />
            ))
          )}
        </div>
      </div>
    </div>
  );
}
