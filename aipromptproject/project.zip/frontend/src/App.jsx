import { Navigate, Route, Routes, useOutletContext } from "react-router";
import { useState, useEffect } from "react";
import AuthIframeModal from "./users/components/AuthIframeModal.jsx";
import UserLayout from "./users/layouts/UserLayout.jsx";
import BuyerRating from "./users/pages/BuyerRating.jsx";
import CreatorHome from "./users/pages/CreatorHome.jsx";
import CreatorRating from "./users/pages/CreatorRating.jsx";
import CreatorProfile from "./users/pages/CreatorProfile.jsx";
import Followings from "./users/pages/Followings.jsx";
import PurchasedPrompt from "./users/pages/PurchasedPrompt.jsx";
import PromptDetail from "./users/pages/PromptDetail.jsx";
import ProfileSettings from "./users/pages/ProfileSettings.jsx";
import UserHome from "./users/pages/UserHome.jsx";
import CreatePrompt from "./users/pages/CreatePrompt.jsx";
import FullPromptContent from "./users/pages/FullPromptContent.jsx";
import CreatorDashboard from "./users/pages/CreatorDashboard.jsx";
import ExchangePage from "./users/pages/Exchange.jsx";
import UserReports from "./users/pages/UserReports.jsx";
import CreatorReports from "./users/pages/CreatorReports.jsx";
import { SocketProvider } from "./users/context/SocketContext.jsx";
import SocketListener from "../../websocket/SocketListener.jsx";

function CreatorOnly({ children }) {
  const { isCreatorMode } = useOutletContext();

  if (!isCreatorMode) {
    return <Navigate to="/" replace />;
  }

  return children;
}

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(
    !!sessionStorage.getItem("promptai_user_id")
  );

  useEffect(() => {
    const checkAuth = () => {
      setIsAuthenticated(!!sessionStorage.getItem("promptai_user_id"));
    };
    window.addEventListener("storage", checkAuth);
    return () => window.removeEventListener("storage", checkAuth);
  }, []);

  const handleLoginSuccess = () => {
    setIsAuthenticated(true);
    window.dispatchEvent(new Event("promptai:user-profile-updated"));
  };

  return (
    <>
      {/* !isAuthenticated && <AuthIframeModal onLoginSuccess={handleLoginSuccess} /> */}
      <SocketProvider>
        <SocketListener />
      <Routes>
        <Route element={<UserLayout />}>
        <Route index element={<UserHome />} />
        <Route path="purchased" element={<PurchasedPrompt />} />
        <Route path="followings" element={<Followings />} />
        <Route path="prompt/:promptId" element={<PromptDetail />} />
        <Route path="prompt/:promptId/full" element={<FullPromptContent />} />
        <Route path="creator/:creatorId" element={<CreatorProfile />} />
        <Route path="user/:userId" element={<CreatorProfile />} />
        <Route path="settings/profile" element={<ProfileSettings />} />
        <Route path="rating" element={<BuyerRating />} />
        <Route path="exchange" element={<ExchangePage />} />
        <Route path="reports" element={<UserReports />} />

        <Route
          path="ratingreceive"
          element={<CreatorRating />}
        />

        <Route
          path="creator/reports"
          element={
            <CreatorOnly>
              <CreatorReports />
            </CreatorOnly>
          }
        />

        <Route
          path="creator"
          element={<CreatorHome />}
        />

        <Route
          path="creator/creatordashboard"
          element={
            <CreatorOnly>
              <CreatorDashboard />
            </CreatorOnly>
          }
        />

        <Route
          path="createpost/:promptId?"
          element={<CreatePrompt />}
        />

        {/* Legacy redirects */}
        <Route path="community" element={<Navigate to="/followings" replace />} />
        <Route path="favorites" element={<Navigate to="/rating" replace />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
    </SocketProvider>
    </>
  );
}
